package com.tu.libraryManagementSystemBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSystemBackendApplication.class, args);
	}

}
